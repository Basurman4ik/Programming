package com._1lab.firma;
import java.util.Scanner;
public class Sotrudnik {String fam, im, otch, doljnost;
    int kolDet;
    Rebenok []reb= null;
}
class Rebenok{
    String imaR;
    int vozrastR;
}
