package com._1lab.firma;

import java.util.Scanner;

public class Firma { // головний клас
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in, "cp1251");

        System.out.println("Enter number of workers => ");
        int kol = sc.nextInt();
        sc.nextLine();

        Sotrudnik[] sotr = new Sotrudnik[kol];

        System.out.println("Enter the info about each worker:");

        for (int i = 0; i < sotr.length; i++) {
            sotr[i] = new Sotrudnik();

            System.out.print("Enter the surname of the " + (i + 1) + " worker => ");
            sotr[i].fam = sc.nextLine();

            System.out.print("Enter his name => ");
            sotr[i].im = sc.nextLine();

            System.out.print("Enter his father's name => ");
            sotr[i].otch = sc.nextLine();

            System.out.print("Enter his occupation => ");
            sotr[i].doljnost = sc.nextLine();

            System.out.print("Enter the number of his children => ");
            sotr[i].kolDet = sc.nextInt();
            sc.nextLine();

            if (sotr[i].kolDet != 0) {
                sotr[i].reb = new Rebenok[sotr[i].kolDet];
                System.out.println("Children =>");
                for (int j = 0; j < sotr[i].reb.length; j++) {
                    sotr[i].reb[j] = new Rebenok();
                    System.out.print("Enter the name of " + (j + 1) + "th children => ");
                    sotr[i].reb[j].imaR = sc.nextLine();
                    System.out.print("Enter his age => ");
                    sotr[i].reb[j].vozrastR = sc.nextInt();
                    sc.nextLine();
                }
            }
        }
        System.out.println("\nCompany workers:\nSurname\tname\tfather's name\toccupation");
        for (Sotrudnik s : sotr) {
            System.out.println(s.fam + "\t" + s.im + "\t" + s.otch + "\t" + s.doljnost);
            System.out.println("Children: ");
            if (s.kolDet != 0) {
                for (Rebenok r : s.reb)
                    System.out.println("\t\t" + r.imaR + "\t\t" + r.vozrastR);
            }
            else
            {
                System.out.println("0");
            }
            System.out.println("");
        }
    }
}
