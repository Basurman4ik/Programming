package Theatre;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;
public class Sorting {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in, "cp1251");

        System.out.println("Enter the number of theatres => ");
        int n = sc.nextInt(); // кількість театрів
        Theatre theatre[] = new Theatre[n];
        System.out.println("Enter the information about theater");
        for (int i = 0; i < theatre.length; i++) {
            sc.nextLine(); // очищення буфера
            theatre[i] = new Theatre();
            System.out.print("Name of the " + (i + 1) + "th theatre");
            theatre[i].name = sc.nextLine();
            System.out.print("Name of the director of " + (i + 1) + "th theatre");
            theatre[i].ruler = sc.nextLine();
            System.out.print("Adress of the " + (i + 1) + "th theatre");
            theatre[i].adress = sc.nextLine();
            System.out.print("Rating of " + (i + 1) + "th theatre");
            theatre[i].rating = sc.nextInt();
        }
        System.out.println("\nTheatre descriptions");
        for (int i = 0; i < theatre.length; i++) {

            System.out.println("" + theatre[i].name + "\t" + theatre[i].ruler + "\t" + theatre[i].adress + "\t" + theatre[i].rating);
        }
        // Театр з найвищим рейтингом
        int nommax=0; //номер елемента для театра з найвищим рейтингом (початкове значення)

        double max=theatre[nommax].rating; //максимальний рейтинг (початкове значення)
        for (int i = 0; i < theatre.length; i++) if (theatre[i].rating>max) {
            max = theatre [i]. rating;
            nommax=i;
        }
        System.out.println("\nTheatre with highest rating ");
        System.out.println(""+theatre[nommax].name+"\t"+theatre[nommax].rating + "");

        // Сортування театрів за рейтингом

        for (int i = 0; i < theatre.length-1; i++)
        {
            for (int j = 0; j < theatre.length-i-1; j++)
            {
                if(theatre[j].rating < theatre[j+1].rating)
                {
                    Theatre temp = theatre[j];
                    theatre[j]=theatre[j+1];
                    theatre[j+1]=temp;
                }
            }

        }
        System.out.println("\nSorted list by rating: ");
        for (int i = 0; i< theatre.length; i++)
        {
            System.out.println("" + theatre[i].name + "\t" + theatre[i].ruler + "\t" + theatre[i].adress + "\t" + theatre[i].rating);
        }

        // Театри з більшим рейтинго ніж заданий
        System.out.println("Enter the rating => ");
        int s = sc.nextInt(); // заданий рейтинг
        System.out.println("\nTheatres with rating bigger than entered value");
        for (int i = 0; i < theatre.length; i++) {
            if (theatre[i].rating>s)
                System.out.println("" + theatre[i].name + "\t" + theatre[i].ruler + "\t" + theatre[i].adress + "\t" + theatre[i].rating);
        }
        // Пошук за назвою
        sc.nextLine(); // очищення буфера
        System.out.println("Enter the name of the director you are looking for=>");
        String name=sc.nextLine();
        int nom = -1;
        for (int i = 0; i < theatre.length; i++)
            if (name.equalsIgnoreCase(theatre[i].ruler)) nom=i;
        if (nom != -1)
        {
            System.out.println("There is such director in the list. It's " +theatre[nom].name+" "+theatre[nom].ruler+" "+theatre[nom].adress+" "+theatre[nom].rating+" ");
            System.out.println("What do you want to change?");
            System.out.println("1 - name; 2 - director; 3 - adress; 4 - rating.");
            int choose = sc.nextInt(); // вибір
            if (choose == 1)
            {
                System.out.println("Enter new data");
                sc.nextLine();
                theatre[nom].name = sc.nextLine();
                System.out.println("Info updated");
            }
            else if (choose == 2)
            {
                System.out.println("Enter new data");
                sc.nextLine();
                theatre[nom].ruler = sc.nextLine();
                System.out.println("Info updated");
            }
            else if (choose == 3)
            {
                System.out.println("Enter new data");
                sc.nextLine();
                theatre[nom].adress = sc.nextLine();
                System.out.println("Info updated");
            }
            else if (choose == 4)
            {
                System.out.println("Enter new data");
                sc.nextLine();
                theatre[nom].rating = sc.nextInt();
                System.out.println("Info updated");
            }
            else System.out.println("You entered not correct data");
            System.out.println("");
            System.out.println("Updated data about theatre " +theatre[nom].name+" "+theatre[nom].ruler+" "+theatre[nom].adress+" "+theatre[nom].rating+" ");
        }
        else System.out.println("There is no such director in the list");
    }
}


