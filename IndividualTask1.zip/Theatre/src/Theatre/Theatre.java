package Theatre;


public class Theatre {
    String name; // назва країни
    String ruler; // назва країни
    String adress; // назва країни
    int rating; // площа країни
}