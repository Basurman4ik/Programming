package laba;
import java.util.Scanner;
import java.lang.Exception;
public class massive {
    public static void main(String[] args) {
        Matrix();

    }
    public static void Matrix()
    {
        Scanner sc = new Scanner(System.in, "cp1251");
        System.out.println("Enter the size of the matrix:");

        int size = sc.nextInt();

        int max = Integer.MIN_VALUE;
        int[][] matrix = new int[size][size];
        System.out.println("Enter the numbers:");
        try {
            for (int i = 0; i < matrix.length; i++) {
                for (int j = 0; j < matrix[i].length; j++) {
                    matrix[i][j] = sc.nextInt();
                }
            }
        } catch (Exception string) {
            System.out.println("ERROR! Enter the numbers, not the words");
            Matrix();
        }
        System.out.println("Matrix:");
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                System.out.printf("%6d", matrix[i][j]);
            }
            System.out.println();
        }
        try {
            for (int i = matrix.length - 1; i >= 0; i--) {
                for (int j = 0; j < size; j++) {
                    if (i == j) {
                        if (matrix[i][j] % 2 == 0) {
                            if (max < matrix[i][j]) {
                                max = matrix[i][j];
                            }
                        }
                        if (max == Integer.MIN_VALUE) {
                            throw new IllegalArgumentException("There is no even number");
                        }
                    }
                }
            }
        }
        catch (Exception stringTwo) {
            System.out.println("ERROR! There is no even number");
            Matrix();
        }

        System.out.println("Maximum number on the diagonal: " + max);
        System.exit(0);
    }
}



