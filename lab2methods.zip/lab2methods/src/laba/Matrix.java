package laba;

public class Matrix {
}
