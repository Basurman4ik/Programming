package com.example.myhello;

import java.util.ArrayList;
import java.util.Arrays;
public class students {

    private String name;
    private String groupNumber;

    public students(String name, String groupNumber){
        this.name=name;
        this.groupNumber=groupNumber;

    }
    public String getName(){
        return name;
    }
    public String getGroupNumber(){
        return groupNumber;
    }
    private final static ArrayList <students> students =new ArrayList<students>(
            Arrays.asList(
                    new students("Савченко Олександр", "303"),
                    new students("Кабак Дмитро", "302"),
                    new students("Кислова Марина", "302"),
                    new students("Серських Тимофій", "309"),
                    new students("Кирилов Данил", "305"),
                    new students("Гнутов Назар", "301"),
                    new students("Лагутін Микита", "301"),
                    new students("Алєєв Тимур", "305")
                    )
    );
    public static ArrayList<students> getStudents (String groupNumber){
        ArrayList<students> stlist=new ArrayList<>();
        for (students s: students){
            if (s.getGroupNumber().equals(groupNumber)){
                stlist.add(s);
            }
        }
        return stlist;
    }

}

